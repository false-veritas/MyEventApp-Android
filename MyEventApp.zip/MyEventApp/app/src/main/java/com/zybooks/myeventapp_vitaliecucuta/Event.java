package com.zybooks.myeventapp_vitaliecucuta;

public class Event {

    private String date;
    private String description;

    public Event (String newDate, String newDescription) {
        date = newDate;
        description = newDescription;

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
