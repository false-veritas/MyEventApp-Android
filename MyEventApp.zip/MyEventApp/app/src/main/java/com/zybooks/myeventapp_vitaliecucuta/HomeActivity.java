package com.zybooks.myeventapp_vitaliecucuta;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = "HomeActivity";

    int count;

    DBEventHelper myDB;
    Button btnView;
    private ListView mListView;
    ArrayList<Event> listData = new ArrayList<>();

    final Fragment fragment1 = new HomeFragment();
    final Fragment fragment2 = new CalendarFragment();
    final Fragment fragment3 = new HistoryFragment();
    final Fragment fragment4 = new ProfileFragment();
    FragmentManager fm = getSupportFragmentManager();
    Fragment active = fragment1;

    NavController navController;
    BottomNavigationView bottomNavigationView;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        myDB = new DBEventHelper(this);
        mListView = (ListView) findViewById(R.id.listView);
        btnView = (Button) findViewById(R.id.populateList);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        toolbar = findViewById(R.id.toolbar);
        navController = Navigation.findNavController(this, R.id.navHostFragment);
        setupBottomNavBar();
        setupToolbar();

        bottomNavigationView.setOnItemSelectedListener(navListener);

        //create fragments
        fm.beginTransaction().add(R.id.fragment_container, fragment4, "4").hide(fragment4).commit();
        fm.beginTransaction().add(R.id.fragment_container, fragment3, "3").hide(fragment3).commit();
        fm.beginTransaction().add(R.id.fragment_container, fragment2, "2").hide(fragment2).commit();
        fm.beginTransaction().add(R.id.fragment_container, fragment1, "1").commit();

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });

        populateListView();


    }
    /**
     * Populate home frag with list data
     *
     */
    private void populateListView() {
        Log.d(TAG, "populateListView: Displaying data in the ListView.");

        //get the data and append to a list
        Cursor data = myDB.getData();

        while(data.moveToNext()){
            //get the value from the database in column 1
            //then add it to the ArrayList
            Event event = new Event(data.getString(1), data.getString(2));
            listData.add(0, event);

        }
        //create the list adapter and set the adapter
        TwoColumn_ListAdapter adapter = new TwoColumn_ListAdapter(this, R.layout.list_adapter, listData);
        mListView.setAdapter(adapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String date = parent.getItemAtPosition(position).toString();
                //String description = parent.getItemAtPosition(position).toString();

                Cursor data = myDB.getItemID(date);
                int itemID = -1;

                while(data.moveToNext()) {
                    itemID = data.getInt(0);
                }

                if(itemID > -1) {
                    Log.d(TAG, "onItemClick: The ID is: " + itemID);
                    Intent editEvent = new Intent(HomeActivity.this, EditEventActivity.class);
                    editEvent.putExtra("id", itemID);
                    editEvent.putExtra("date", date);
                    //editEvent.putExtra("description", description);
                    startActivity(editEvent);
                }
                else {
                    Toast.makeText(HomeActivity.this, "No ID associated", Toast.LENGTH_SHORT).show();
                }

            }
        });

        };


    private void setupBottomNavBar() {
        NavigationUI.setupWithNavController(bottomNavigationView, navController);
    }

    private void setupToolbar() {

        setSupportActionBar(toolbar);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder
                (R.id.nav_home,
                 R.id.nav_calendar,
                 R.id.nav_add,
                 R.id.nav_history,
                 R.id.nav_profile).build();
        NavigationUI.setupWithNavController(toolbar, navController, appBarConfiguration);
    }

    private NavigationBarView.OnItemSelectedListener navListener
            = new NavigationBarView.OnItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.nav_home:
                    fm.beginTransaction().hide(active).show(fragment1).commit();
                    active = fragment1;
                    return true;

                case R.id.nav_calendar:
                    fm.beginTransaction().hide(active).show(fragment2).commit();
                    active = fragment2;
                    return true;

                case R.id.nav_add:
                    Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);
                    startActivity(intent);
                    return true;

                case R.id.nav_history:
                    fm.beginTransaction().hide(active).show(fragment3).commit();
                    active = fragment3;
                    return true;
                case R.id.nav_profile:
                    fm.beginTransaction().hide(active).show(fragment4).commit();
                    active = fragment4;
                    return true;
            }
            return true;
        }
    };


}