package com.zybooks.myeventapp_vitaliecucuta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class TwoColumn_ListAdapter extends ArrayAdapter<Event> {

    private Context mContext;
    int mViewResourceId;

    public TwoColumn_ListAdapter(Context context, int textViewResourceId, ArrayList<Event> events) {
        super(context, textViewResourceId, events);

        mContext = context;
        mViewResourceId = textViewResourceId;

    }

    public View getView(int position, View convertView, ViewGroup parents) {
        String date = getItem(position).getDate();
        String description = getItem(position).getDescription();

        Event event = new Event(date, description);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mViewResourceId, parents, false);

        TextView dateText = (TextView) convertView.findViewById(R.id.textDate);
        TextView descriptionText = (TextView) convertView.findViewById(R.id.textDescription);

        dateText.setText(date);
        descriptionText.setText(description);

        return convertView;
    }
}
