package com.zybooks.myeventapp_vitaliecucuta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class AddEventActivity extends AppCompatActivity {

    private static final String TAG = "AddEvent";

    DBEventHelper dbEventHelper;
    private Button btnAdd;
    private EditText dateText, descriptionText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dateText = (EditText) findViewById(R.id.editDate);
        descriptionText = (EditText) findViewById(R.id.editDescription);
        btnAdd = (Button) findViewById(R.id.addButton);
        dbEventHelper = new DBEventHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String newDate = dateText.getText().toString();
                String newDescription = descriptionText.getText().toString();

                if(newDate != "" || newDescription != "") {
                    AddData(newDate, newDescription);
                    dateText.setText("");
                    descriptionText.setText("");

                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddEventActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void AddData(String newDate, String newDescription) {
        boolean insertData = dbEventHelper.addData(newDate, newDescription);

        if(insertData==true)
            Toast.makeText(AddEventActivity.this, "Successfully inserted data", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(AddEventActivity.this, "ERROR!", Toast.LENGTH_SHORT).show();
    }
}