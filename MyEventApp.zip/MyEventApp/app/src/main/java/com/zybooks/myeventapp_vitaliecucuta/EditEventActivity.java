package com.zybooks.myeventapp_vitaliecucuta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {

    private static final String TAG = "AddEvent";

    DBEventHelper dbEventHelper;
    private Button btnSave, btnDelete;
    private EditText dateText, descriptionText;

    private String selectedDate;
    private String selectedDescription;
    private int selectedID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        btnSave = (Button) findViewById(R.id.saveButton);
        btnDelete = (Button) findViewById(R.id.deleteButton);
        dateText = (EditText) findViewById(R.id.editDate1);
        descriptionText = (EditText) findViewById(R.id.editDescription1);
        dbEventHelper = new DBEventHelper(this);

        //get the intent extra from the HomeActivity
        Intent receivedIntent = getIntent();

        //get the itemID passed as an extra
        selectedID = receivedIntent.getIntExtra("id", -1);

        //get the date and description passed as an extra
        selectedDate = receivedIntent.getStringExtra("date");
        selectedDescription = receivedIntent.getStringExtra("description");

        //set the text to show the current selected date and description
        dateText.setText(selectedDate);
        descriptionText.setText(selectedDescription);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String date = dateText.getText().toString();
                String description = descriptionText.getText().toString();

                if(date != "" || description != "") {

                    dbEventHelper.updateEvent(date, description, selectedID, selectedDate, selectedDescription);
                    Toast.makeText(EditEventActivity.this, "Event updated", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(intent);

                }
                else {
                    Toast.makeText(EditEventActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbEventHelper.deleteEvent(selectedID, selectedDate, selectedDescription);
                dateText.setText("");
                descriptionText.setText("");
                Toast.makeText(EditEventActivity.this, "Removed from database", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });


    }
}