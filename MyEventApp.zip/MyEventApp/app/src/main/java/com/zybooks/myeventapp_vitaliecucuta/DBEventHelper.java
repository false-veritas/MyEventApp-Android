package com.zybooks.myeventapp_vitaliecucuta;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBEventHelper extends SQLiteOpenHelper {

    private static final String TAG = "DBEventHelper";

    private static final String TABLE_NAME = "event_table";
    private static final String Col1 = "ID";
    private static final String Col2 = "Date";
    private static final String Col3 = "Description";

    public DBEventHelper(Context context) {
        super(context, TAG, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Col2 + " TEXT, " + Col3 + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String date, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Col2, date);
        contentValues.put(Col3, description);

        Log.d(TAG, "addData: Adding " + date + " and " + description + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    /**
     * Returns all the data from database
     * @return
     */
    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query,null);
        return data;
    }

    /**
     * Returns only the ID that matches the date and description passed in
     * @param date
     * //@param description
     * @return
     */
    public Cursor getItemID(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + Col1 + " FROM " + TABLE_NAME +
                " WHERE " + Col2 + " = '" + date + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    /**
     * Updates the date and description field
     * @param editDate
     * @param editDescription
     * @param eventId
     * @param olderDate
     * @param oldDescription
     */
    public void updateEvent(String editDate, String editDescription, int eventId, String olderDate, String oldDescription) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + TABLE_NAME +
                       " SET " + Col2 + " = '" + editDate + "', " +
                       Col3 + " = '" + editDescription +
                        "' WHERE " + Col1 + " = '" + eventId + "'" +
                        " AND " + Col2 + " = '" + olderDate + "', " +
                       Col3 + " = '" + oldDescription + "'";
        Log.d(TAG, "updateEvent: query: " + query);
        Log.d(TAG, "updateEvent: Setting event to " + editDate + " and " + editDescription);
        db.execSQL(query);

    }

    /**
     * Delete from database
     * @param id
     * @param date
     * @param description
     */
    public void deleteEvent(int id, String date, String description) {

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_NAME + " WHERE " +
                        Col1 + " = '" + id + "'" + " AND " +
                        Col2 + " = '" + date + "', " +
                        Col3 + " = '" + description + "'";
        db.execSQL(query);

    }
}
